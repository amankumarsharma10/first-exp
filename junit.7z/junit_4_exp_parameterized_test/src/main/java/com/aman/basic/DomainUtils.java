package com.aman.basic;

import java.util.regex.Pattern;

/**
 * Created by Aman on 29-12-2016.
 */
public class DomainUtils {

    private static final String DOMAIN_NAME_PATTERN = "^((?!-)[A-Za-z0-9-]{1,63}(?!-)\\.)+[A-Za-z]{2,6}$";
    private static Pattern pattern = Pattern.compile(DOMAIN_NAME_PATTERN);

    public boolean isValid(String domain){
        return pattern.matcher(domain).find();
    }
}
