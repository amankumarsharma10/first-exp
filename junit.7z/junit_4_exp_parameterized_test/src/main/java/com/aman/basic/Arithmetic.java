package com.aman.basic;

/**
 * Created by Aman on 29-12-2016.
 */
public class Arithmetic {

    public int sum(int a, int b){
        return a+b;
    }
}
