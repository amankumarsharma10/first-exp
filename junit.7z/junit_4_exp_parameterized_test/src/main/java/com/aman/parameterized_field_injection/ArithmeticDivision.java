package com.aman.parameterized_field_injection;

/**
 * Created by Aman on 29-12-2016.
 */
public class ArithmeticDivision {

    public int divide(int a, int b){
        return a/b;
    }
}
