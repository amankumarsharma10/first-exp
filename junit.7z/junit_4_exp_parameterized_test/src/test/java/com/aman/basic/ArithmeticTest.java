package com.aman.basic;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

import java.util.Arrays;
import java.util.Collection;

/**
 * Created by Aman on 29-12-2016.
 */

@RunWith(Parameterized.class)
public class ArithmeticTest {

    private int first;
    private int second;
    private int expected;

    Arithmetic arithmetic = new Arithmetic();

    public ArithmeticTest(int first, int second, int expected) {
        this.first = first;
        this.second = second;
        this.expected = expected;
    }

    @Parameterized.Parameters(name = "{index}: testAdd({0}+{1}) = {2}") // name parameter is optional
    public static Collection<Integer[]> addNumbers(){
        return Arrays.asList(new Integer[][]{{1,2,3},{-1,2,1},{5,-2,3},{-1,-2,-3}});
    }

    @Test
    public void testSum(){
        int result = arithmetic.sum(first,second);

        Assert.assertEquals(expected,result);
    }
}
