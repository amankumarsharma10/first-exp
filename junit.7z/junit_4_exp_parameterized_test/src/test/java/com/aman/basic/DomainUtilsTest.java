package com.aman.basic;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

import java.util.Arrays;
import java.util.Collection;

/**
 * Created by Aman on 29-12-2016.
 */

@RunWith(Parameterized.class)
public class DomainUtilsTest {

    private String domain;
    private DomainUtils domainUtils;

    public DomainUtilsTest(String domain) {
        this.domain = domain;
    }

    @Before
    public void initialize(){
        domainUtils = new DomainUtils();
    }

    @Parameterized.Parameters
    public static Collection<String > validCases(){
       return Arrays.asList(new String []{
                "google.com",
                "epam.com",
                "www.google.co.in"
        });
    }

    @Test
    public void testIsValid(){
        boolean result = domainUtils.isValid(domain);
        Assert.assertTrue(result);
    }
}
