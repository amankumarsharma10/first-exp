package com.aman.parameterized_field_injection;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

import java.util.Arrays;
import java.util.Collection;

/**
 * Created by Aman on 29-12-2016.
 */

@RunWith(Parameterized.class)
public class ArithmeticDivisionTest {

    @Parameterized.Parameter(value = 0)
    public int first;                   //should be public

    @Parameterized.Parameter(value = 1)
    public int second;                  //should be public

    @Parameterized.Parameter(value = 2)
    public int expected;                //should be public

    private ArithmeticDivision arithmetic;


    @Before
    public void initialize(){
        arithmetic = new ArithmeticDivision();
    }

    @Parameterized.Parameters(name = "{index}: testAdd({0}/{1}) = {2}") // name parameter is optional
    public static Collection<Integer[]> addNumbers(){
        return Arrays.asList(new Integer[][]{{1,2,0},{-2,1,-2},{5,-2,-2},{-6,-2,3}});
    }

    @Test
    public void testDivide(){
        int result = arithmetic.divide(first,second);

        Assert.assertEquals(expected,result);
    }
}
