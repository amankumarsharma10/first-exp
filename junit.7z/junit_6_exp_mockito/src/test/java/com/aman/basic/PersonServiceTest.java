package com.aman.basic;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

/**
 * Created by Aman on 29-12-2016.
 */
public class PersonServiceTest {

    @Mock
    private PersonDAO personDAO;
    private PersonService personService;

    @Before
    public void setUp(){
        MockitoAnnotations.initMocks(this);
        personService = new PersonService(personDAO);
    }

    @Test
    public void testShouldUpdatePersonName(){
        Person person = new Person(1, "Phillip");
        Mockito.when(personDAO.fetchPerson(1)).thenReturn(person);

        boolean update = personService.upadte(1,"Aman");

        Assert.assertTrue(update);

        Mockito.verify(personDAO).fetchPerson(1);

        ArgumentCaptor<Person> personArgumentCaptor = ArgumentCaptor.forClass(Person.class);
        Mockito.verify(personDAO).updatePerson(personArgumentCaptor.capture());
        Person updatePerson = personArgumentCaptor.getValue();

        Assert.assertEquals("Aman",updatePerson.getPersonName());
        Mockito.verifyNoMoreInteractions(personDAO);
    }

    @Test
    public void testShouldNotUpdateIfPersonNotFound()
    {
        Mockito.when( personDAO.fetchPerson( 1 ) ).thenReturn( null );
        boolean updated = personService.upadte( 1, "David" );
        Assert.assertFalse( updated );
        Mockito.verify( personDAO ).fetchPerson( 1 );
        Mockito.verifyZeroInteractions( personDAO );
        Mockito.verifyNoMoreInteractions( personDAO );
    }
}
