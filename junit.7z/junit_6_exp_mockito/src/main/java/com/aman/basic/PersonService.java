package com.aman.basic;

/**
 * Created by Aman on 29-12-2016.
 */
public class PersonService {

    private final PersonDAO personDAO;

    public PersonService(PersonDAO personDAO) {
        this.personDAO = personDAO;
    }

    public boolean upadte(Integer personID, String personName){
        Person person = personDAO.fetchPerson(personID);
        if (person != null){
            Person updatedPerson = new Person( person.getPersonId(), personName );
            personDAO.updatePerson( updatedPerson );
            return true;
        }
        else return false;
    }
}
