package com.aman.basic;

/**
 * Created by Aman on 29-12-2016.
 */
public interface PersonDAO {
    public Person fetchPerson(Integer personId);
    public boolean updatePerson( Person person );
}
