package com.aman.basic;

/**
 * Created by Aman on 29-12-2016.
 */
public class Person {

    private Integer personId;
    private String personName;

    public Person(Integer personId, String personName) {
        this.personId = personId;
        this.personName = personName;
    }

    public Integer getPersonId() {
        return personId;
    }

    public String getPersonName() {
        return personName;
    }
}
